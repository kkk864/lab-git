﻿namespace Pacman
{
    class Energizer : Dot
    {
        public Energizer(int x, int y) : base(x, y, 50)
        {

        }
    }
}
