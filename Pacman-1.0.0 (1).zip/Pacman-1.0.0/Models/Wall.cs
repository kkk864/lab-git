﻿namespace Pacman
{
    class Wall : Tile
    {
        public Wall(int x, int y): base(x, y)
        {

        }
    }
}
